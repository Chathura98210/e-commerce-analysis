import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import "./home.scss";
import Widget from "../../components/widget/HomeWidget";
import Chart from "../../components/chart/HomeChart";
import { useState,useEffect } from "react";
import axios from "axios";

const Home = () => {

  const [ isDataLoaded , setIsDataLoaded] = useState(false);
  const [ stat , setStat] = useState();

  useEffect(()=>{
    axios.get(`http://localhost:5000/homestat`).then((res,err)=>{
      if(res){
        setStat(res.data);
        console.log(res.data);
        setIsDataLoaded(true);
      }
    })
  },[])

  return (
    <div className="home">
      <Sidebar />
      <div className="homeContainer">
        <Navbar />
        {
          isDataLoaded ?
          <div className="widgets">
          <Widget type="clicks" stat = {stat}/>
          <Widget type="addtocard" stat = {stat} />
          <Widget type="orders" stat = {stat}/>
          <Widget type="stock" stat = {stat} />
        </div>:
        <div className="item">
        data loading...
      </div>
        }
        <div className="charts">
          <Chart title="Orders In last week" aspect={10 / 3} />
        </div>
      </div>
    </div>
  );
};

export default Home;
