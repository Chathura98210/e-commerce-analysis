import "./single.scss";
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import { useParams } from "react-router-dom"
import { useState,useEffect } from "react";
import axios from "axios";

const Order = () => {

  const params = useParams();
  console.log(params.ordId)

  const [ isDataLoaded , setIsDataLoaded] = useState(false);

  const [ order , setOrder] = useState();
  const [ items , setItems] = useState();
  // /itemviewed/:id
  useEffect(()=>{
    axios.get(`http://localhost:5000/order/${params.ordId}`).then((res,err)=>{
      if(res){
        setOrder(res.data[0]);
        console.log(res.data[0]);
        axios.get(`http://localhost:5000/getitemsoforder/${params.ordId}`).then((resp,errp)=>{
          if(resp){
            setItems(resp.data);
            console.log(resp.data);
            setIsDataLoaded(true);
          }
        })
      }
    })
  },[params.ordId])

  return (
    <div className="single">
      <Sidebar />
      <div className="singleContainer">
        <Navbar />
        {
          isDataLoaded?
          <div className="top">
          <div className="left">
            <div className="item">
              <div className="details">
                <h1 className="itemTitle">Order Info</h1>
                <div className="detailItem">
                  <span className="itemKey">Date:</span>
                  <span className="itemValue">{order.date}</span>
                </div>
                <div className="detailItem">
                  <span className="itemKey">UserName:</span>
                  <span className="itemValue">{order.name}</span>
                </div>
                <div className="detailItem">
                  <span className="itemKey">Address:</span>
                  <span className="itemValue">
                  {order.address}
                  </span>
                </div>
                <div className="detailItem">
                  <span className="itemKey">Contact:</span>
                  <span className="itemValue">{order.contact === "" ? 'No contact provided' : order.contact}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        :
        <div>Data Loading...</div>
        }

{/* catId: "32"
description: "Apple Iphone 11 64gb"
id: 6
imgUrl: "http://localhost:5000/images/apple-iphone-11-mobile-phones.jpg"
isFeatured: 1
itemId: 6
name: "Apple Iphone 11"
price: "100000"
rating: null
stock: 5
subCatId: "12" */}
        
        <div className="top">
          <div className="left">
            <div className="item">
              <div className="details">
                <h1 className="itemTitle">Items List</h1>
                <table>
  <tr>
    <th>Item Id</th>
    <th>Image</th>
    <th>Item Name</th>
    <th>Item Price</th>
    <th>Quantity</th>
  </tr>
  
  

                { isDataLoaded ?
                  items.map(item =>{
                    return(
                      <tr>
                      <td>{item.id}</td>
                      <td>
                          <img className="cellImg" src={item.imgUrl} alt="avatar" />
                      </td>
                      <td>{item.name}</td>
                      <td>{item.price} LKR</td>
                      <td>1</td>
                    </tr>
                    )
                  })
                  :
                  <div>Data Loading...</div>
                }
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Order;