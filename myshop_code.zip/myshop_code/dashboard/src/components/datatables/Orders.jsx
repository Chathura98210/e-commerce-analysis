import "./datatable.scss";
import { DataGrid } from "@mui/x-data-grid";
import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from "axios";
const Orders = () => {

  const userColumns = [
    { field: "id", headerName: "ID", width: 70 },
    {
      field: "name",
      headerName: "User name",
      width: 230,
      renderCell: (params) => {
        return (
          <div className="cellWithImg">
            {params.row.name}
          </div>
        );
      },
    },
    {
      field: "date",
      headerName: "Date",
      width: 230,
    }
  ];

  const actionColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 200,
      renderCell: (params) => {
        return (
          <div className="cellAction">
            <Link to={`/orders/${params.row.id}`} style={{ textDecoration: "none" }}>
              <div className="viewButton">View</div>
            </Link>
          </div>
        );
      },
    },
  ];

  const [ orders , setOrders] = useState([]);

  useEffect(()=>{
    axios.get('http://localhost:5000/orders').then((res,err)=>{
      if(res){
        setOrders(res.data)
        console.log(res.data);
      }
    })
  },[]);


  return (
    <div className="datatable">
      <DataGrid
        className="datagrid"
        rows={orders}
        columns={userColumns.concat(actionColumn)}
        pageSize={9}
        rowsPerPageOptions={[9]}
        checkboxSelection
      />
    </div>
  );
};

export default Orders;