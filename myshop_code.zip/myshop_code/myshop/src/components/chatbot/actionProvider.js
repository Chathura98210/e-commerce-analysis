import React from 'react';
import { useState,useEffect } from "react";
import axios from "axios";

const ActionProvider = ({ createChatBotMessage, setState, children }) => {

    const [ categories , setCategories] = useState();

    useEffect(()=>{
      axios.get(`http://localhost:5000/categories`).then((res,err)=>{
        if(res){
          setCategories(res.data);
          console.log(res.data);
        }
      })
    },[])

    const [ items , setItems] = useState();

  useEffect(()=>{
    axios.get(`http://localhost:5000/items`).then((res,err)=>{
      if(res){
        setItems(res.data);
        console.log(res.data);  
      }
    })
  },[]);

  const handleHello = () => {
    const botMessage = createChatBotMessage('Hello, Welcome to myshop online chat!');

    setState((prev) => ({
      ...prev,
      messages: [...prev.messages, botMessage],
    }));
  };

  const handleInStock = (itemname) => {
    let botMessage = createChatBotMessage(`I am unable to understand your question please call us on   012 345 67 89   or reach us via hello@myshop.com `);
    items.forEach(element => {
        if(itemname.includes(element.name.toLowerCase())){
            
            botMessage = createChatBotMessage(`We have ${element.name.toLowerCase()} in our stocks!`);
        }
    });
    setState((prev) => ({
      ...prev,
      messages: [...prev.messages, botMessage],
    }));
  };

  const handleNumProducts = () => {
    const botMessage = createChatBotMessage(`We have ${items.length} products currently available`);

    setState((prev) => ({
      ...prev,
      messages: [...prev.messages, botMessage],
    }));
  };

  const handleNumCategories = () => {
    const botMessage = createChatBotMessage(`We have ${categories.length} categories currently available`);

    setState((prev) => ({
      ...prev,
      messages: [...prev.messages, botMessage],
    }));
  };

  const handleContactDetails = () => {
    const botMessage = createChatBotMessage('please call us on   012 345 67 89   or reach us via hello@myshop.com');

    setState((prev) => ({
      ...prev,
      messages: [...prev.messages, botMessage],
    }));
  };

  const handleNotResponded = () =>{
    let botMessage = createChatBotMessage(`I am unable to understand your question please call us on   012 345 67 89   or reach us via hello@myshop.com `);
    setState((prev) => ({
      ...prev,
      messages: [...prev.messages, botMessage],
    }));
  }
  // Put the handleHello function in the actions object to pass to the MessageParser
  return (
    <div>
      {React.Children.map(children, (child) => {
        return React.cloneElement(child, {
          actions: {
            handleHello,
            handleNumCategories,
            handleNumProducts,
            handleContactDetails,
            handleInStock,
            handleNotResponded
          },
        });
      })}
    </div>
  );
};

export default ActionProvider;