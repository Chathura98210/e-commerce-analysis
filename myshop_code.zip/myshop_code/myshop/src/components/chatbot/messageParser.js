// export default MessageParser;

import React from 'react';

const MessageParser = ({ children, actions }) => {
  let responded = false;
  const parse = (message) => {
        const lowercase = message.toLowerCase();

        if(lowercase.includes("hello") || lowercase.includes("hi") || lowercase.includes("hay") || lowercase.includes("hey")){
            responded = true;
            actions.handleHello();
        }

        if(lowercase.includes("how") && lowercase.includes("many")){

            if(lowercase.includes("items") || lowercase.includes("products")){
                responded = true;
                actions.handleNumProducts()
            }

            if(lowercase.includes("categor") || lowercase.includes("groups")){
                responded = true;
                actions.handleNumCategories();
            }
            
        }

        if(lowercase.includes("stock")){
            responded = true;
            actions.handleInStock(lowercase)
        }

        if(lowercase.includes("contact") || lowercase.includes("telephone") || lowercase.includes("mobile")){
            responded = true;
            actions.handleContactDetails()
        }

        if(!responded){
            actions.handleNotResponded()
        }
  };

  return (
    <div>
      {React.Children.map(children, (child) => {
        return React.cloneElement(child, {
          parse: parse,
          actions: {},
        });
      })}
    </div>
  );
};

export default MessageParser;