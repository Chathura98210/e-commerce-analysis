import React from 'react'
import Home from '../components/mainpage/Home'

function Pages() {
  return (
    <>
        <Home/>
    </>
  )
}

export default Pages