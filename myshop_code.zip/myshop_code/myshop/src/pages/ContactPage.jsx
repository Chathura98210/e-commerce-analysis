import {React} from 'react';

function ContactPage() {
  return (
    <>
      <div className='about-page-container'>
            <div className='about-header'>Contact us</div>
            <div className='contact-content-container'>
                <h3>Address</h3>
                <br />
                <div>NO 123/4,<br/> XYZ Road,<br/> PQR.
                </div>
                <br />
                <div>
                <h3>Contact no</h3>
                <br />
                <div>+123 45 67 89</div>
                <br />
                    
                </div>
            </div>
        </div>   
    </>
  )
}

export default ContactPage