import {React} from 'react';

function AboutPage() {
  return (
    <>
        <div className='about-page-container'>
            <div className='about-header'>About us</div>
            <div className='about-content'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dicta, iste quibusdam! Maxime voluptatibus asperiores, placeat eaque dignissimos, cum ducimus omnis molestiae amet veniam, sed labore itaque dolores optio debitis qui.</div>
            <div className='about-content'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dicta, iste quibusdam! Maxime voluptatibus asperiores, placeat eaque dignissimos, cum ducimus omnis molestiae amet veniam, sed labore itaque dolores optio debitis qui.</div>
            <div className='about-content'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dicta, iste quibusdam! Maxime voluptatibus asperiores, placeat eaque dignissimos, cum ducimus omnis molestiae amet veniam, sed labore itaque dolores optio debitis qui.</div>
        </div>  
    </>
  )
}

export default AboutPage