// INSERT INTO `users` (`id`, `name`, `username`, `password`, `rec_1`, `rec_2`, `rec_3`, `rec_4`, `rec_5`, `recent_1`, `recent_2`, `recent_3`, `recent_4`, `recent_5`) VALUES (NULL, 'test', 'testuser', 'password', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
const pool = require('../connection')
exports.addOrder = async(req, res, next) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadId}`)

        const { name, address, contact, items } = req.body;



        const getItemsQuery = (orderId) => {
            let itemslist = ``;
            for (let i = 0; i < items.length; i++) {
                if (i == items.length - 1) {
                    itemslist = itemslist + `(${orderId},${items[i].id},1)`
                } else {
                    itemslist = itemslist + `(${orderId},${items[i].id},1),`
                }

            }
            let items_query = `INSERT INTO item_order(orderId, itemId, amount) VALUES` + itemslist + `;`;

            return items_query;
        }

        connection.query('INSERT INTO orders SET name = ?, address = ?, contact = ?;', [name, address, contact], (err, rows) => {


            if (!err) {
                connection.query('SELECT LAST_INSERT_ID() as id from orders;', (errp, rowsp) => { // return the connection to pool
                    connection.query(getItemsQuery(rowsp[0].id), (errpp, rowspp) => {
                        connection.release() // return the connection to pool
                        res.send(`order added.`)
                    })
                })

            } else {
                console.log(err)
            }

        })

        console.log(req.body)
    })
};


exports.getOrders = async(req, res, next) => {
    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadId}`)

        connection.query('SELECT * from orders', (err, rows) => {
            connection.release() // return the connection to pool

            if (!err) {
                res.send(rows)
            } else {
                console.log(err)
            }

        })
    })
};


exports.getOrderById = async(req, res, next) => {
    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadId}`)

        connection.query('SELECT * from orders WHERE id = ?', [req.params.id], (err, rows) => {
            connection.release() // return the connection to pool

            if (!err) {
                res.send(rows)
            } else {
                console.log(err)
            }

        })
    })
};

exports.getOrderItemsById = async(req, res, next) => {
    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadId}`)

        connection.query(`SELECT item_order.itemId,items.* from item_order JOIN items ON item_order.itemId = items.id WHERE item_order.orderId = ?`, [req.params.id], (err, rows) => {
            connection.release() // return the connection to pool

            if (!err) {
                res.send(rows)
            } else {
                console.log(err)
            }

        })
    })
};



exports.getLastWeekOrders = async(req, res, next) => {
    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadId}`)
        connection.query(`SELECT COUNT(*) AS count,DATE_FORMAT(date,'%y-%m-%d') AS date FROM orders WHERE date BETWEEN date_sub(now(),INTERVAL 1 WEEK) AND now() GROUP BY DATE(date) ORDER BY date DESC`, [req.params.id], (err, rows) => {
            connection.release() // return the connection to pool

            if (!err) {
                res.send(rows)
            } else {
                console.log(err)
            }

        })
    })
};